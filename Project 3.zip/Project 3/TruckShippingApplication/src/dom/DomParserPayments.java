package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class DomParserPayments {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String PaymentID="", OrderID="", TransactionID="", PaymentMethodID="", PaymentAmount="", PaymentDate="", 
		CheckNumber="", CreditCardNumber="", CardholdersName="", CreditCardExpDate="", CVV="";
		DomParserPayments Dom = new DomParserPayments();
		try {
			File inputFile = new File("XML/payments.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("payment");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					PaymentID = eElement
							.getElementsByTagName("paymentID")
							.item(0)
							.getTextContent();
					System.out.println("Payment ID : " 
							+ eElement
							.getElementsByTagName("paymentID")
							.item(0)
							.getTextContent());
					
					OrderID = eElement
							.getElementsByTagName("orderID")
							.item(0)
							.getTextContent();
					System.out.println("Order ID : " 
							+ eElement
							.getElementsByTagName("orderID")
							.item(0)
							.getTextContent());
					
					TransactionID = eElement
							.getElementsByTagName("transactionID")
							.item(0)
							.getTextContent();
					System.out.println("Transaction ID : " 
							+ eElement
							.getElementsByTagName("transactionID")
							.item(0)
							.getTextContent());
					
					PaymentMethodID = eElement
							.getElementsByTagName("paymentMethodID")
							.item(0)
							.getTextContent();
					System.out.println("Payment Method ID : " 
							+ eElement
							.getElementsByTagName("paymentMethodID")
							.item(0)
							.getTextContent());
					
					PaymentAmount = eElement
							.getElementsByTagName("paymentAmount")
							.item(0)
							.getTextContent();
					System.out.println("Payment Amount : " 
							+ eElement
							.getElementsByTagName("paymentAmount")
							.item(0)
							.getTextContent());
					
					PaymentDate = eElement
							.getElementsByTagName("paymentDate")
							.item(0)
							.getTextContent();
					System.out.println("Payment Date : " 
							+ eElement
							.getElementsByTagName("paymentDate")
							.item(0)
							.getTextContent());
					
					CheckNumber = eElement
							.getElementsByTagName("checkNumber")
							.item(0)
							.getTextContent();
					System.out.println("Check Number : " 
							+ eElement
							.getElementsByTagName("checkNumber")
							.item(0)
							.getTextContent());
					
					CreditCardNumber = eElement
							.getElementsByTagName("creditCardNumber")
							.item(0)
							.getTextContent();
					System.out.println("Credit Card Number : " 
							+ eElement
							.getElementsByTagName("creditCardNumber")
							.item(0)
							.getTextContent());
					
					CardholdersName = eElement
							.getElementsByTagName("cardholdersName")
							.item(0)
							.getTextContent();
					System.out.println("Card Holders Name : " 
							+ eElement
							.getElementsByTagName("cardholdersName")
							.item(0)
							.getTextContent());
					
					CreditCardExpDate = eElement
							.getElementsByTagName("creditCardExpDate")
							.item(0)
							.getTextContent();
					System.out.println("Credit Card Expiry Date : " 
							+ eElement
							.getElementsByTagName("creditCardExpDate")
							.item(0)
							.getTextContent());
					
					CVV = eElement
							.getElementsByTagName("cVV")
							.item(0)
							.getTextContent();
					System.out.println("CVV : " 
							+ eElement
							.getElementsByTagName("cVV")
							.item(0)
							.getTextContent());
					

					Dom.insert(PaymentID, OrderID, TransactionID, PaymentMethodID, PaymentAmount, PaymentDate, 
							CheckNumber, CreditCardNumber, CardholdersName, CreditCardExpDate, CVV);
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public int insert(String PaymentID, String OrderID, String TransactionID, String PaymentMethodID, 
			String PaymentAmount, String PaymentDate, String CheckNumber, String CreditCardNumber, 
			String CardholdersName, String CreditCardExpDate, String CVV) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into payments(paymentID,orderID,transactionID,paymentMethodID,paymentAmount,paymentDate,checkNumber,creditCardNumber,cardholdersName,creditCardExpDate,cVV) values(?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,PaymentID);
			preparedStatement.setString(2,OrderID);
			preparedStatement.setString(3,TransactionID);
			preparedStatement.setString(4,PaymentMethodID);
			preparedStatement.setString(5,PaymentAmount);
			preparedStatement.setString(6,PaymentDate);
			preparedStatement.setString(7,CheckNumber);
			preparedStatement.setString(8,CreditCardNumber);
			preparedStatement.setString(9,CardholdersName);
			preparedStatement.setString(10,CreditCardExpDate);
			preparedStatement.setString(11,CVV);
			
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}