package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class DomParserEmployees {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String EmployeeID="",FirstName="",LastName="",EmailId="",Extension="",HomePhone="",CellPhone="",
				JobTitle="",SSNo="",DriverLicenseNum="",StreetAddress="",City="",State="",PostalCode="",
				BirthDate="",DateHire="",Salary="",Notes="";
		DomParserEmployees Dom = new DomParserEmployees();
		try {
			File inputFile = new File("XML/employees.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("employee");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					EmployeeID = eElement
							.getElementsByTagName("employeeID")
							.item(0)
							.getTextContent();
					System.out.println("Employee ID : " 
							+ eElement
							.getElementsByTagName("employeeID")
							.item(0)
							.getTextContent());
					
					FirstName = eElement
							.getElementsByTagName("firstName")
							.item(0)
							.getTextContent();
					System.out.println("First Name : " 
							+ eElement
							.getElementsByTagName("firstName")
							.item(0)
							.getTextContent());
					
					LastName = eElement
							.getElementsByTagName("lastName")
							.item(0)
							.getTextContent();
					System.out.println("Last Name : " 
							+ eElement
							.getElementsByTagName("lastName")
							.item(0)
							.getTextContent());
					
					EmailId = eElement
							.getElementsByTagName("emailId")
							.item(0)
							.getTextContent();
					System.out.println("Email Id : " 
							+ eElement
							.getElementsByTagName("emailId")
							.item(0)
							.getTextContent());
					
					Extension = eElement
							.getElementsByTagName("extension")
							.item(0)
							.getTextContent();
					System.out.println("Extension : " 
							+ eElement
							.getElementsByTagName("extension")
							.item(0)
							.getTextContent());
					
					HomePhone = eElement
							.getElementsByTagName("homePhone")
							.item(0)
							.getTextContent();
					System.out.println("Home Phone : " 
							+ eElement
							.getElementsByTagName("homePhone")
							.item(0)
							.getTextContent());
					
					CellPhone = eElement
							.getElementsByTagName("cellPhone")
							.item(0)
							.getTextContent();
					System.out.println("Cell Phone : " 
							+ eElement
							.getElementsByTagName("cellPhone")
							.item(0)
							.getTextContent());
					
					JobTitle = eElement
							.getElementsByTagName("jobTitle")
							.item(0)
							.getTextContent();
					System.out.println("Job Title : " 
							+ eElement
							.getElementsByTagName("jobTitle")
							.item(0)
							.getTextContent());
					
					SSNo = eElement
							.getElementsByTagName("SSN")
							.item(0)
							.getTextContent();
					System.out.println("Social Security # : " 
							+ eElement
							.getElementsByTagName("SSN")
							.item(0)
							.getTextContent());
					
					DriverLicenseNum = eElement
							.getElementsByTagName("driverLicenseNum")
							.item(0)
							.getTextContent();
					System.out.println("Driver License Number : " 
							+ eElement
							.getElementsByTagName("driverLicenseNum")
							.item(0)
							.getTextContent());
					
					StreetAddress = eElement
							.getElementsByTagName("streetAddress")
							.item(0)
							.getTextContent();
					System.out.println("Street Address : " 
							+ eElement
							.getElementsByTagName("streetAddress")
							.item(0)
							.getTextContent());
					
					City= eElement
							.getElementsByTagName("city")
							.item(0)
							.getTextContent();
					System.out.println("City : " 
							+ eElement
							.getElementsByTagName("city")
							.item(0)
							.getTextContent());
					
					State = eElement
							.getElementsByTagName("state")
							.item(0)
							.getTextContent();
					System.out.println("State : " 
							+ eElement
							.getElementsByTagName("state")
							.item(0)
							.getTextContent());
					
					PostalCode = eElement
							.getElementsByTagName("postalCode")
							.item(0)
							.getTextContent();
					System.out.println("Postal Code : " 
							+ eElement
							.getElementsByTagName("postalCode")
							.item(0)
							.getTextContent());
					
					BirthDate = eElement
							.getElementsByTagName("birthDate")
							.item(0)
							.getTextContent();
					System.out.println("Birth Date : " 
							+ eElement
							.getElementsByTagName("birthDate")
							.item(0)
							.getTextContent());
					
					DateHire = eElement
							.getElementsByTagName("dateHire")
							.item(0)
							.getTextContent();
					System.out.println("Date Hired : " 
							+ eElement
							.getElementsByTagName("dateHire")
							.item(0)
							.getTextContent());
					
					Salary = eElement
							.getElementsByTagName("salary")
							.item(0)
							.getTextContent();
					System.out.println("Salary : " 
							+ eElement
							.getElementsByTagName("salary")
							.item(0)
							.getTextContent());
					
					Notes = eElement
							.getElementsByTagName("notes")
							.item(0)
							.getTextContent();
					System.out.println("Notes : " 
							+ eElement
							.getElementsByTagName("notes")
							.item(0)
							.getTextContent());
					
					Dom.insert(EmployeeID, FirstName, LastName, EmailId, Extension, HomePhone, CellPhone, 
							JobTitle, SSNo, DriverLicenseNum, StreetAddress, City, State, PostalCode,
							BirthDate,DateHire,Salary,Notes);
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public int insert(String EmployeeID, String FirstName, String LastName, String EmailId, String Extension, 
			String HomePhone, String CellPhone, String JobTitle, String SSNo, String DriverLicenseNum, 
			String StreetAddress, String City, String State, String PostalCode, String BirthDate, 
			String DateHire, String Salary, String Notes) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into employees(employeeID,firstName,lastName,emailId,extension,homePhone,cellPhone,jobTitle,SSN,driverLicenseNum,streetAddress,city,state,postalCode,birthDate,dateHire,salary,notes) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,EmployeeID);
			preparedStatement.setString(2,FirstName);
			preparedStatement.setString(3,LastName);
			preparedStatement.setString(4,EmailId);
			preparedStatement.setString(5,Extension);
			preparedStatement.setString(6,HomePhone);
			preparedStatement.setString(7,CellPhone);
			preparedStatement.setString(8,JobTitle);
			preparedStatement.setString(9,SSNo);
			preparedStatement.setString(10,DriverLicenseNum);
			preparedStatement.setString(11,StreetAddress);
			preparedStatement.setString(12,City);
			preparedStatement.setString(13,State);
			preparedStatement.setString(14,PostalCode);
			preparedStatement.setString(15,BirthDate);
			preparedStatement.setString(16,DateHire);
			preparedStatement.setString(17,Salary);
			preparedStatement.setString(18,Notes);
			
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}