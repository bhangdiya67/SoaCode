package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class DomParserLocations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String LocID="", LocName="", LocCode="", IsAuction="", CustomerID="", AddressStreet1="", AddressStreet2="",
				City="", State="", PostalCode="", Country="", LocContactName="", LocPhoneNumber="", 
						LocFaxNumber="", LocEmail="";
		DomParserLocations Dom = new DomParserLocations(); 
		try {
			File inputFile = new File("XML/locations.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("location");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					LocID   =   eElement
							.getElementsByTagName("locID")
							.item(0)
							.getTextContent();
					System.out.println("Location ID : " 
							+ eElement
							.getElementsByTagName("locID")
							.item(0)
							.getTextContent());
					
					LocName   =   eElement
							.getElementsByTagName("locName")
							.item(0)
							.getTextContent();
					System.out.println("Location Name : " 
							+ eElement
							.getElementsByTagName("locName")
							.item(0)
							.getTextContent());
					
					LocCode   =   eElement
							.getElementsByTagName("locCode")
							.item(0)
							.getTextContent();
					System.out.println("Location Code : " 
							+ eElement
							.getElementsByTagName("locCode")
							.item(0)
							.getTextContent());
					
					IsAuction   =   eElement
							.getElementsByTagName("isAuction")
							.item(0)
							.getTextContent();
					System.out.println("Is Auction ? : " 
							+ eElement
							.getElementsByTagName("isAuction")
							.item(0)
							.getTextContent());
					
					CustomerID   =   eElement
							.getElementsByTagName("customerID")
							.item(0)
							.getTextContent();
					System.out.println("Customer ID : " 
							+ eElement
							.getElementsByTagName("customerID")
							.item(0)
							.getTextContent());
					
					AddressStreet1   =   eElement
							.getElementsByTagName("addressStreet1")
							.item(0)
							.getTextContent();
					System.out.println("Address Street 1 : " 
							+ eElement
							.getElementsByTagName("addressStreet1")
							.item(0)
							.getTextContent());
					
					AddressStreet2   =   eElement
							.getElementsByTagName("addressStreet2")
							.item(0)
							.getTextContent();
					System.out.println("Address Street 2 : " 
							+ eElement
							.getElementsByTagName("addressStreet2")
							.item(0)
							.getTextContent());
					
					City= eElement
							.getElementsByTagName("city")
							.item(0)
							.getTextContent();
					System.out.println("City : " 
							+ eElement
							.getElementsByTagName("city")
							.item(0)
							.getTextContent());
					
					State = eElement
							.getElementsByTagName("state")
							.item(0)
							.getTextContent();
					System.out.println("State : " 
							+ eElement
							.getElementsByTagName("state")
							.item(0)
							.getTextContent());
					
					PostalCode = eElement
							.getElementsByTagName("postalCode")
							.item(0)
							.getTextContent();
					System.out.println("Postal Code : " 
							+ eElement
							.getElementsByTagName("postalCode")
							.item(0)
							.getTextContent());
					
					Country   =   eElement
							.getElementsByTagName("country")
							.item(0)
							.getTextContent();
					System.out.println("Country : " 
							+ eElement
							.getElementsByTagName("country")
							.item(0)
							.getTextContent());
					
					LocContactName   =   eElement
							.getElementsByTagName("locContactName")
							.item(0)
							.getTextContent();
					System.out.println("Location Contact Name: " 
							+ eElement
							.getElementsByTagName("locContactName")
							.item(0)
							.getTextContent());
					
					LocPhoneNumber   =   eElement
							.getElementsByTagName("locPhoneNumber")
							.item(0)
							.getTextContent();
					System.out.println("Location Phone Number: " 
							+ eElement
							.getElementsByTagName("locPhoneNumber")
							.item(0)
							.getTextContent());
					
					LocFaxNumber   =   eElement
							.getElementsByTagName("locFaxNumber")
							.item(0)
							.getTextContent();
					System.out.println("Location Fax Number: " 
							+ eElement
							.getElementsByTagName("locFaxNumber")
							.item(0)
							.getTextContent());
					
					LocEmail   =   eElement
							.getElementsByTagName("locEmail")
							.item(0)
							.getTextContent();
					System.out.println("Location Email: " 
							+ eElement
							.getElementsByTagName("locEmail")
							.item(0)
							.getTextContent());
					
					Dom.insert(LocID,LocName,LocCode,IsAuction,CustomerID,AddressStreet1,AddressStreet2,
							City,State,PostalCode,Country,LocContactName,LocPhoneNumber,
							LocFaxNumber,LocEmail);
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}
	public int insert(String LocID, String LocName, String LocCode, String IsAuction, String CustomerID, 
			String AddressStreet1, String AddressStreet2, String City, String State, String PostalCode, 
			String Country, String LocContactName, String LocPhoneNumber, String LocFaxNumber, String 
			LocEmail) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into locations(locID,locName,locCode,isAuction,customerID,addressStreet1,addressStreet2,city,state,postalCode,country,locContactName,locPhoneNumber,locFaxNumber,locEmail) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,LocID);
			preparedStatement.setString(2,LocName);
			preparedStatement.setString(3,LocCode);
			preparedStatement.setString(4,IsAuction);
			preparedStatement.setString(5,CustomerID);
			preparedStatement.setString(6,AddressStreet1);
			preparedStatement.setString(7,AddressStreet2);
			preparedStatement.setString(8,City);
			preparedStatement.setString(9,State);
			preparedStatement.setString(10,PostalCode);
			preparedStatement.setString(11,Country);
			preparedStatement.setString(12,LocContactName);
			preparedStatement.setString(13,LocPhoneNumber);
			preparedStatement.setString(14,LocFaxNumber);
			preparedStatement.setString(15,LocEmail);
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}
