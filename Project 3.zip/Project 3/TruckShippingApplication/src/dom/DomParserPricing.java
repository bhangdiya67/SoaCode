package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class DomParserPricing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String PriceID="", LocationIDFrom="", LocationIDTo="", Price="",LocationCodeFrom="",
		LocationCodeTo="", LocationNameFrom="", LocationNameTo="", CustomerID="";
		DomParserPricing Dom = new DomParserPricing();      
		try { 
			File inputFile = new File("XML/pricing.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("shippingCost");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;

					PriceID = eElement
							.getElementsByTagName("priceID")
							.item(0)
							.getTextContent(); 
					System.out.println("Price ID : " 
							+ eElement
							.getElementsByTagName("priceID")
							.item(0)
							.getTextContent());

					LocationIDFrom = eElement
							.getElementsByTagName("locationIDFrom")
							.item(0)
							.getTextContent(); 
					System.out.println("Location ID From : " 
							+ eElement
							.getElementsByTagName("locationIDFrom")
							.item(0)
							.getTextContent());

					LocationIDTo = eElement
							.getElementsByTagName("locationIDTo")
							.item(0)
							.getTextContent(); 
					System.out.println("Location ID To : " 
							+ eElement
							.getElementsByTagName("locationIDTo")
							.item(0)
							.getTextContent());

					Price = eElement
							.getElementsByTagName("price")
							.item(0)
							.getTextContent(); 
					System.out.println("Price: " 
							+ eElement
							.getElementsByTagName("price")
							.item(0)
							.getTextContent());

					LocationCodeFrom = eElement
							.getElementsByTagName("locationCodeFrom")
							.item(0)
							.getTextContent(); 
					System.out.println("Location Code From : " 
							+ eElement
							.getElementsByTagName("locationCodeFrom")
							.item(0)
							.getTextContent());

					LocationCodeTo = eElement
							.getElementsByTagName("locationCodeTo")
							.item(0)
							.getTextContent(); 
					System.out.println("Location Code To : " 
							+ eElement
							.getElementsByTagName("locationCodeTo")
							.item(0)
							.getTextContent());

					LocationNameFrom = eElement
							.getElementsByTagName("locationNameFrom")
							.item(0)
							.getTextContent(); 
					System.out.println("Location Name From : " 
							+ eElement
							.getElementsByTagName("locationNameFrom")
							.item(0)
							.getTextContent());

					LocationNameTo = eElement
							.getElementsByTagName("locationNameTo")
							.item(0)
							.getTextContent(); 
					System.out.println("Location Name To : " 
							+ eElement
							.getElementsByTagName("locationNameTo")
							.item(0)
							.getTextContent());

					CustomerID = eElement
							.getElementsByTagName("customerID")
							.item(0)
							.getTextContent(); 
					System.out.println("Customer ID : " 
							+ eElement
							.getElementsByTagName("customerID")
							.item(0)
							.getTextContent());
					
					Dom.insert(PriceID,LocationIDFrom,LocationIDTo,Price,LocationCodeFrom,
							LocationCodeTo,LocationNameFrom,LocationNameTo,CustomerID);

				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}


	public int insert(String PriceID, String LocationIDFrom, String LocationIDTo, String Price,
			String LocationCodeFrom, String LocationCodeTo, String LocationNameFrom, String LocationNameTo, 
			String CustomerID) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			//String sql = CommentID+";"+CommentTime+";"+CommentDate+";"+Comment+";"+commentType;
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into pricing(priceID,locationIDFrom,locationIDTo,price,locationCodeFrom,locationCodeTo,locationNameFrom,locationNameTo,customerID) values(?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,PriceID);
			preparedStatement.setString(2,LocationIDFrom);
			preparedStatement.setString(3,LocationIDTo);
			preparedStatement.setString(4,Price);
			preparedStatement.setString(5,LocationCodeFrom);
			preparedStatement.setString(6,LocationCodeTo);
			preparedStatement.setString(7,LocationNameFrom);
			preparedStatement.setString(8,LocationNameTo);
			preparedStatement.setString(9,CustomerID);
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}

