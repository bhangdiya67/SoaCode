package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;



public class DomParserOrders {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String OrderID="", OrderDate="", CustomerID="", EmployeeID="", TruckNo="", IsSpecial="", PON="", OrderTotalAmount="";
		DomParserOrders Dom = new DomParserOrders(); 
		try {
			File inputFile = new File("XML/orders.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("order");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					OrderID   =   eElement
							.getElementsByTagName("orderID")
							.item(0)
							.getTextContent();
					System.out.println("Order ID : " 
							+ eElement
							.getElementsByTagName("orderID")
							.item(0)
							.getTextContent());
					
					OrderDate   =   eElement
							.getElementsByTagName("orderDate")
							.item(0)
							.getTextContent();
					System.out.println("Order Date : " 
							+ eElement
							.getElementsByTagName("orderDate")
							.item(0)
							.getTextContent());
					
					CustomerID   =   eElement
							.getElementsByTagName("customerID")
							.item(0)
							.getTextContent();
					System.out.println("Customer ID : " 
							+ eElement
							.getElementsByTagName("customerID")
							.item(0)
							.getTextContent());
					
					EmployeeID   =   eElement
							.getElementsByTagName("employeeID")
							.item(0)
							.getTextContent();
					System.out.println("Employee ID : " 
							+ eElement
							.getElementsByTagName("employeeID")
							.item(0)
							.getTextContent());
					
					TruckNo   =   eElement
							.getElementsByTagName("truckNo")
							.item(0)
							.getTextContent();
					System.out.println("Truck No : " 
							+ eElement
							.getElementsByTagName("truckNo")
							.item(0)
							.getTextContent());
					
					IsSpecial   =   eElement
							.getElementsByTagName("isSpecial")
							.item(0)
							.getTextContent();
					System.out.println("Is Special? : " 
							+ eElement
							.getElementsByTagName("isSpecial")
							.item(0)
							.getTextContent());
					
					PON   =   eElement
							.getElementsByTagName("pON")
							.item(0)
							.getTextContent();
					System.out.println("Purchase Order Number : " 
							+ eElement
							.getElementsByTagName("pON")
							.item(0)
							.getTextContent());
					
					OrderTotalAmount   =   eElement
							.getElementsByTagName("orderTotalAmount")
							.item(0)
							.getTextContent();
					System.out.println("Order Total Amount : " 
							+ eElement
							.getElementsByTagName("orderTotalAmount")
							.item(0)
							.getTextContent());
					
					Dom.insert(OrderID, OrderDate, CustomerID, EmployeeID, TruckNo, 
							IsSpecial, PON, OrderTotalAmount);
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}


	public int insert(String OrderID, String OrderDate, String CustomerID, String EmployeeID, String TruckNo, 
			String IsSpecial, String PON, String OrderTotalAmount) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			//String sql = CommentID+";"+CommentTime+";"+CommentDate+";"+Comment+";"+commentType;
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into orders(orderID,orderDate,customerID,employeeID,truckNo,isSpecial,pON,orderTotalAmount) values(?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,OrderID);
			preparedStatement.setString(2,OrderDate);
			preparedStatement.setString(3,CustomerID);
			preparedStatement.setString(4,EmployeeID);
			preparedStatement.setString(5,TruckNo);
			preparedStatement.setString(6,IsSpecial);
			preparedStatement.setString(7,PON);
			preparedStatement.setString(8,OrderTotalAmount);
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}

