package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
public class DomParserTrucks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String TruckNo ="", Make="",Model ="",Year ="", LicensePlate = "", EmployeeID = "", 
				Color = "", Vin = "", TruckCost="";
		DomParserTrucks Dom = new DomParserTrucks(); 
		try {
			File inputFile = new File("XML/trucks.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("truck");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					TruckNo = eElement
								.getElementsByTagName("truckNo")
								.item(0)
								.getTextContent();
					System.out.println("Truck No : " 
							+ eElement
							.getElementsByTagName("truckNo")
							.item(0)
							.getTextContent());
					
					Make = eElement
							.getElementsByTagName("make")
							.item(0)
							.getTextContent();
				System.out.println("Make : " 
							+ eElement
							.getElementsByTagName("make")
							.item(0)
							.getTextContent());

				Model = eElement
							.getElementsByTagName("model")
							.item(0)
							.getTextContent();
				System.out.println("Model : " 
							+ eElement
							.getElementsByTagName("model")
							.item(0)
							.getTextContent());

				Year = eElement
							.getElementsByTagName("year")
							.item(0)
							.getTextContent();
				System.out.println("Year : " 
							+ eElement
							.getElementsByTagName("year")
							.item(0)
							.getTextContent());

				LicensePlate = eElement
							.getElementsByTagName("licenseplateNo")
							.item(0)
							.getTextContent();
				System.out.println("License Plate No : " 
							+ eElement
							.getElementsByTagName("licenseplateNo")
							.item(0)
							.getTextContent());
				
				EmployeeID = eElement
						.getElementsByTagName("employeeID")
						.item(0)
						.getTextContent();	
				System.out.println("Employee ID : " 
							+ eElement
							.getElementsByTagName("employeeID")
							.item(0)
							.getTextContent());
				
				Color = eElement
						.getElementsByTagName("color")
						.item(0)
						.getTextContent();
				System.out.println("Color : " 
						+ eElement
						.getElementsByTagName("color")
						.item(0)
						.getTextContent());

				Vin = eElement
						.getElementsByTagName("VIN")
						.item(0)
						.getTextContent();
				System.out.println("VIN : " 
						+ eElement
						.getElementsByTagName("VIN")
						.item(0)
						.getTextContent());
			
				TruckCost = eElement
						.getElementsByTagName("truckCost")
						.item(0)
						.getTextContent();
				System.out.println("Truck Cost : " 
							+ eElement
							.getElementsByTagName("truckCost")
							.item(0)
							.getTextContent());
				
				Dom.insert(TruckNo,Make,Model,Year,LicensePlate,EmployeeID,Color,Vin,TruckCost);

				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

public int insert(String VehicleID, String Make, String Model,String Year,
		String LicensePlate, String EmployeeID, String Color, String Vin, 
		String TruckCost ) throws SQLException
	{		  
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into trucks(truckNo,make,model,year,licenseplateNo,employeeID,color,VIN,truckCost) values(?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,VehicleID);
			preparedStatement.setString(2,Make);
			preparedStatement.setString(3,Model);
			preparedStatement.setString(4,Year);
			preparedStatement.setString(5,LicensePlate);
			preparedStatement.setString(6,EmployeeID);
			preparedStatement.setString(7,Color);
			preparedStatement.setString(8,Vin);
			preparedStatement.setString(9,TruckCost);
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}

