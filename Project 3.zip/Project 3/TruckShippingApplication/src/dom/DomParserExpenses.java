package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class DomParserExpenses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ExpenseID="", EmployeeID="", ExpenseType="", PurposeofExpense="", AmountSpent="",
				Description="", DatePurchased="", DateSubmitted="",AdvanceAmount="", PaymentMethod="";
		DomParserExpenses Dom = new DomParserExpenses();
		try {
			File inputFile = new File("XML/expenses.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("expense");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					ExpenseID   =   eElement
							.getElementsByTagName("expenseID")
							.item(0)
							.getTextContent();
					System.out.println("Expense ID : " 
							+ eElement
							.getElementsByTagName("expenseID")
							.item(0)
							.getTextContent());	
					
					EmployeeID   =   eElement
							.getElementsByTagName("employeeID")
							.item(0)
							.getTextContent();
					System.out.println("Employee ID : " 
							+ eElement
							.getElementsByTagName("employeeID")
							.item(0)
							.getTextContent());	
					
					ExpenseType   =   eElement
							.getElementsByTagName("expenseType")
							.item(0)
							.getTextContent();
					System.out.println("Expense Type : " 
							+ eElement
							.getElementsByTagName("expenseType")
							.item(0)
							.getTextContent());	
					
					PurposeofExpense   =   eElement
							.getElementsByTagName("purposeofExpense")
							.item(0)
							.getTextContent();
					System.out.println("Purpose of Expense : " 
							+ eElement
							.getElementsByTagName("purposeofExpense")
							.item(0)
							.getTextContent());	
					
					AmountSpent   =   eElement
							.getElementsByTagName("amountSpent")
							.item(0)
							.getTextContent();
					System.out.println("Amount Spent : " 
							+ eElement
							.getElementsByTagName("amountSpent")
							.item(0)
							.getTextContent());	
					
					Description   =   eElement
							.getElementsByTagName("description")
							.item(0)
							.getTextContent();
					System.out.println("Description : " 
							+ eElement
							.getElementsByTagName("description")
							.item(0)
							.getTextContent());	
					
					DatePurchased   =   eElement
							.getElementsByTagName("datePurchased")
							.item(0)
							.getTextContent();
					System.out.println("Date Purchased : " 
							+ eElement
							.getElementsByTagName("datePurchased")
							.item(0)
							.getTextContent());	
					
					DateSubmitted   =   eElement
							.getElementsByTagName("dateSubmitted")
							.item(0)
							.getTextContent();
					System.out.println("Date Submitted : " 
							+ eElement
							.getElementsByTagName("dateSubmitted")
							.item(0)
							.getTextContent());	
					
					AdvanceAmount   =   eElement
							.getElementsByTagName("advanceAmount")
							.item(0)
							.getTextContent();
					System.out.println("Advance Amount : " 
							+ eElement
							.getElementsByTagName("advanceAmount")
							.item(0)
							.getTextContent());
					
					PaymentMethod   =   eElement
							.getElementsByTagName("paymentMethod")
							.item(0)
							.getTextContent();
					System.out.println("Payment Method : " 
							+ eElement
							.getElementsByTagName("paymentMethod")
							.item(0)
							.getTextContent());
					
					Dom.insert(ExpenseID, EmployeeID, ExpenseType, PurposeofExpense, AmountSpent,
							Description, DatePurchased, DateSubmitted,AdvanceAmount,PaymentMethod);
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int insert(String ExpenseID, String EmployeeID, String ExpenseType, String PurposeofExpense, 
			String AmountSpent, String Description, String DatePurchased, String DateSubmitted,
			String AdvanceAmount, String PaymentMethod) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into expenses(expenseID,employeeID,expenseType,purposeofExpense,amountSpent,description,datePurchased,dateSubmitted,advanceAmount,paymentMethod) values(?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,ExpenseID);
			preparedStatement.setString(2,EmployeeID);
			preparedStatement.setString(3,ExpenseType);
			preparedStatement.setString(4,PurposeofExpense);
			preparedStatement.setString(5,AmountSpent);
			preparedStatement.setString(6,Description);
			preparedStatement.setString(7,DatePurchased);
			preparedStatement.setString(8,DateSubmitted);
			preparedStatement.setString(9,AdvanceAmount);
			preparedStatement.setString(10,PaymentMethod);
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}

