package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class DomParserComments {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String CommentID="", CommentTime="",CommentDate="",Comment="",commentType="";
		DomParserComments Dom = new DomParserComments();                
		try {
			File inputFile = new File("XML/comments.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("comment");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;

					CommentID   =   eElement
							.getElementsByTagName("commentID")
							.item(0)
							.getTextContent();
					System.out.println("Comment ID : " 
							+ eElement
							.getElementsByTagName("commentID")
							.item(0)
							.getTextContent());

					CommentTime = eElement
							.getElementsByTagName("commentTime")
							.item(0)
							.getTextContent();
					System.out.println("Comment Time : " 
							+ eElement
							.getElementsByTagName("commentTime")
							.item(0)
							.getTextContent());
					CommentDate = eElement
							.getElementsByTagName("commentDate")
							.item(0)
							.getTextContent();
					System.out.println("Comment Date : " 
							+ eElement
							.getElementsByTagName("commentDate")
							.item(0)
							.getTextContent());

					Comment = eElement
							.getElementsByTagName("description")
							.item(0)
							.getTextContent(); 
					System.out.println("Comment : " 
							+ eElement
							.getElementsByTagName("description")
							.item(0)
							.getTextContent());

					commentType = eElement
							.getElementsByTagName("type")
							.item(0)
							.getTextContent(); 
					System.out.println("Type : " 
							+ eElement
							.getElementsByTagName("type")
							.item(0)
							.getTextContent());

					Dom.insert(CommentID,CommentTime,CommentDate,Comment,commentType);

				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}


	public int insert(String CommentID, String CommentTime, String CommentDate,String Comment,String commentType) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			//String sql = CommentID+";"+CommentTime+";"+CommentDate+";"+Comment+";"+commentType;
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into comments(commentID,commentTime,commentDate,description,type) values(?,?,?,?,?)");
			preparedStatement.setString(1,CommentID);
			preparedStatement.setString(2,CommentTime);
			preparedStatement.setString(3,CommentDate);
			preparedStatement.setString(4,Comment);
			preparedStatement.setString(5,commentType);
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}
