package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class DomParserCustomers {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String CustomerID ="", CustomerTitle="",BusinessName ="",BillingAddress ="",City = "",State="",
				Country="",EmailID="",Type="",CompanyName="",ContactName="",AlternateContactName="",DateEntered="",
				PostalCode="",PhoneNumber="",CellNumber="",FaxNumber="";
		DomParserCustomers Dom = new DomParserCustomers(); 
		try {
			File inputFile = new File("XML/customers.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("customer");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					CustomerID = eElement
					.getElementsByTagName("customerID")
					.item(0)
					.getTextContent();
					System.out.println("Customer ID : " 
							+ eElement
							.getElementsByTagName("customerID")
							.item(0)
							.getTextContent());
					
					CustomerTitle = eElement
							.getElementsByTagName("customerID")
							.item(0)
							.getTextContent();
					System.out.println("Customer Title : " 
							+ eElement
							.getElementsByTagName("customerTitle")
							.item(0)
							.getTextContent());
					
					BusinessName = eElement
							.getElementsByTagName("businessName")
							.item(0)
							.getTextContent();
					System.out.println("Business Name : " 
							+ eElement
							.getElementsByTagName("businessName")
							.item(0)
							.getTextContent());
					
					BillingAddress = eElement
							.getElementsByTagName("billingAddress")
							.item(0)
							.getTextContent();
					System.out.println("Billing Address : " 
							+ eElement
							.getElementsByTagName("billingAddress")
							.item(0)
							.getTextContent());
					
					City = eElement
							.getElementsByTagName("city")
							.item(0)
							.getTextContent();
					System.out.println("City : " 
							+ eElement
							.getElementsByTagName("city")
							.item(0)
							.getTextContent());
					
					State = eElement
							.getElementsByTagName("state")
							.item(0)
							.getTextContent();
					System.out.println("State : " 
							+ eElement
							.getElementsByTagName("state")
							.item(0)
							.getTextContent());
					
					PostalCode = eElement
							.getElementsByTagName("postalCode")
							.item(0)
							.getTextContent();
					System.out.println("Postal Code : " 
							+ eElement
							.getElementsByTagName("postalCode")
							.item(0)
							.getTextContent());
					
					Country = eElement
							.getElementsByTagName("country")
							.item(0)
							.getTextContent();
					System.out.println("Country : " 
							+ eElement
							.getElementsByTagName("country")
							.item(0)
							.getTextContent());
					
					PhoneNumber = eElement
							.getElementsByTagName("phoneNumber")
							.item(0)
							.getTextContent();
					System.out.println("Phone Number : " 
							+ eElement
							.getElementsByTagName("phoneNumber")
							.item(0)
							.getTextContent());
					
					EmailID = eElement
							.getElementsByTagName("emailID")
							.item(0)
							.getTextContent();
					System.out.println("Email id : " 
							+ eElement
							.getElementsByTagName("emailID")
							.item(0)
							.getTextContent());
					
					Type = eElement
							.getElementsByTagName("type")
							.item(0)
							.getTextContent();
					System.out.println("Type : " 
							+ eElement
							.getElementsByTagName("type")
							.item(0)
							.getTextContent());
					
					CellNumber = eElement
							.getElementsByTagName("cellNumber")
							.item(0)
							.getTextContent();
					System.out.println("Cell Number : " 
							+ eElement
							.getElementsByTagName("cellNumber")
							.item(0)
							.getTextContent());
					
					FaxNumber = eElement
							.getElementsByTagName("faxNumber")
							.item(0)
							.getTextContent();
					System.out.println("Fax Number : " 
							+ eElement
							.getElementsByTagName("faxNumber")
							.item(0)
							.getTextContent());
					
					CompanyName = eElement
							.getElementsByTagName("companyName")
							.item(0)
							.getTextContent();
					System.out.println("Company Name : " 
							+ eElement
							.getElementsByTagName("companyName")
							.item(0)
							.getTextContent());
					
					ContactName = eElement
							.getElementsByTagName("contactName")
							.item(0)
							.getTextContent();
					System.out.println("Contact Name: " 
							+ eElement
							.getElementsByTagName("contactName")
							.item(0)
							.getTextContent());
					
					AlternateContactName = eElement
							.getElementsByTagName("alternateContactName")
							.item(0)
							.getTextContent();
					System.out.println("Alternate Contact Name : " 
							+ eElement
							.getElementsByTagName("alternateContactName")
							.item(0)
							.getTextContent());
					
					DateEntered = eElement
							.getElementsByTagName("dateEntered")
							.item(0)
							.getTextContent();
					System.out.println("Date Entered : " 
							+ eElement
							.getElementsByTagName("dateEntered")
							.item(0)
							.getTextContent());
					
					Dom.insert(CustomerID, CustomerTitle, BusinessName, BillingAddress, City, State, 
				PostalCode, Country, PhoneNumber, EmailID, Type, CellNumber, FaxNumber,
				CompanyName, ContactName, AlternateContactName, DateEntered);
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public int insert(String CustomerID, String CustomerTitle, String BusinessName, String BillingAddress, String City, String State,
			String PostalCode, String Country, String PhoneNumber, String EmailID, String Type, String CellNumber, String FaxNumber,
			String CompanyName, String ContactName, String AlternateContactName, String DateEntered) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into customers(customerID,customerTitle,businessName,billingAddress,city,state,postalCode,country,phoneNumber,emailID,type,cellNumber,faxNumber,companyName,contactName,alternateContactName,dateEntered) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,CustomerID);
			preparedStatement.setString(2,CustomerTitle);
			preparedStatement.setString(3,BusinessName);
			preparedStatement.setString(4,BillingAddress);
			preparedStatement.setString(5,City);
			preparedStatement.setString(6,State);
			preparedStatement.setString(7,PostalCode);
			preparedStatement.setString(8,Country);
			preparedStatement.setString(9,PhoneNumber);
			preparedStatement.setString(10,EmailID);
			preparedStatement.setString(11,Type);
			preparedStatement.setString(12,CellNumber);
			preparedStatement.setString(13,FaxNumber);
			preparedStatement.setString(14,CompanyName);
			preparedStatement.setString(15,ContactName);
			preparedStatement.setString(16,AlternateContactName);
			preparedStatement.setString(17,DateEntered);
			
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}
