package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class DomParserTickets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String TicketID="", EmployeeID="", TicketDate="", Reason="", Amount="", IsPaid="";
		DomParserTickets Dom = new DomParserTickets();
		try {
			File inputFile = new File("XML/tickets.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("ticket");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;

					TicketID = eElement
							.getElementsByTagName("ticketID")
							.item(0)
							.getTextContent(); 
					System.out.println("Ticket ID : " 
							+ eElement
							.getElementsByTagName("ticketID")
							.item(0)
							.getTextContent());

					EmployeeID = eElement
							.getElementsByTagName("employeeID")
							.item(0)
							.getTextContent(); 
					System.out.println("Employee ID : " 
							+ eElement
							.getElementsByTagName("employeeID")
							.item(0)
							.getTextContent());

					TicketDate = eElement
							.getElementsByTagName("ticketDate")
							.item(0)
							.getTextContent(); 
					System.out.println("Ticket Date : " 
							+ eElement
							.getElementsByTagName("ticketDate")
							.item(0)
							.getTextContent());

					Reason = eElement
							.getElementsByTagName("reason")
							.item(0)
							.getTextContent(); 
					System.out.println("Reason : " 
							+ eElement
							.getElementsByTagName("reason")
							.item(0)
							.getTextContent());

					Amount = eElement
							.getElementsByTagName("amount")
							.item(0)
							.getTextContent(); 
					System.out.println("Amount : " 
							+ eElement
							.getElementsByTagName("amount")
							.item(0)
							.getTextContent());

					IsPaid = eElement
							.getElementsByTagName("isPaid")
							.item(0)
							.getTextContent(); 
					System.out.println("Is Paid? : " 
							+ eElement
							.getElementsByTagName("isPaid")
							.item(0)
							.getTextContent());

					Dom.insert(TicketID,EmployeeID,TicketDate,Reason,Amount,IsPaid);

				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}


	public int insert(String TicketID, String EmployeeID, String TicketDate, String Reason, String Amount, String IsPaid) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			//String sql = CommentID+";"+CommentTime+";"+CommentDate+";"+Comment+";"+commentType;
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into tickets(ticketID,employeeID,ticketDate,reason,amount,isPaid) values(?,?,?,?,?,?)");
			preparedStatement.setString(1,TicketID);
			preparedStatement.setString(2,EmployeeID);
			preparedStatement.setString(3,TicketDate);
			preparedStatement.setString(4,Reason);
			preparedStatement.setString(5,Amount);
			preparedStatement.setString(6,IsPaid);
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}
