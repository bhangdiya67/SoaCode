package dom;

 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbConnection {

    private static Connection con = null;
    public static Connection getConnection()
    {
       try {    
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception e)
        {
            System.out.println(e);
        }

        try
        {
            String url = ("jdbc:mysql://192.168.1.141:3306/truckshipping");
            con = DriverManager.getConnection(url, "root", "admin");
        } catch (SQLException e)
        {
            System.out.println("error "+e);
        }
        return con;
    }
}
