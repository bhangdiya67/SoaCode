package dom;

import java.io.File;
import java.sql.*;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class DomParserTransactions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String TransactionID ="", OrderID="",PriceID ="",TransactionDate ="",TransactionDesc = "",
				TransactionAmount = "", Make="", Model = "", Year = "", EmployeeID, TruckNo = "", 
				Discount = "", Quantity = "", UnitPrice = "", DriverPrice = "", Vin = "", RunNumber = "", 
				IsSpecial = "", Rate = "", Surcharge = "";
		DomParserTransactions Dom = new DomParserTransactions(); 
		try {
			File inputFile = new File("XML/transactions.xml");
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(inputFile);
			document.getDocumentElement().normalize();
			System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("transaction");
			System.out.println("----------------------------");
			for (int temporary = 0; temporary < nodeList.getLength(); temporary++) {
				Node node = nodeList.item(temporary);
				System.out.println("\nCurrent Element :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					TransactionID = eElement
								.getElementsByTagName("transactionID")
								.item(0)
								.getTextContent();
					System.out.println("TransactionID : " 
								+ eElement
								.getElementsByTagName("transactionID")
								.item(0)
								.getTextContent());

					OrderID = eElement
								.getElementsByTagName("orderID")
								.item(0)
								.getTextContent();
					System.out.println("OrderID : " 
								+ eElement
								.getElementsByTagName("orderID")
								.item(0)
								.getTextContent());

					PriceID = eElement
								.getElementsByTagName("priceID")
								.item(0)
								.getTextContent();
					System.out.println("PriceID : " 
								+ eElement
								.getElementsByTagName("priceID")
								.item(0)
								.getTextContent());

					TransactionDate = eElement
								.getElementsByTagName("transactionDate")
								.item(0)
								.getTextContent();
					System.out.println("Transaction Date : " 
								+ eElement
								.getElementsByTagName("transactionDate")
								.item(0)
								.getTextContent());

					TransactionDesc = eElement
								.getElementsByTagName("transactionDesc")
								.item(0)
								.getTextContent();
					System.out.println("Transaction Description : " 
								+ eElement
								.getElementsByTagName("transactionDesc")
								.item(0)
								.getTextContent());

					TransactionAmount = eElement
								.getElementsByTagName("transactionAmount")
								.item(0)
								.getTextContent();
					System.out.println("Transaction Amount : " 
								+ eElement
								.getElementsByTagName("transactionAmount")
								.item(0)
								.getTextContent());

					Make = eElement
								.getElementsByTagName("make")
								.item(0)
								.getTextContent();
					System.out.println("Make : " 
								+ eElement
								.getElementsByTagName("make")
								.item(0)
								.getTextContent());

					Model = eElement
								.getElementsByTagName("model")
								.item(0)
								.getTextContent();
					System.out.println("Model : " 
								+ eElement
								.getElementsByTagName("model")
								.item(0)
								.getTextContent());

					Year = eElement
								.getElementsByTagName("year")
								.item(0)
								.getTextContent();
					System.out.println("Year : " 
								+ eElement
								.getElementsByTagName("year")
								.item(0)
								.getTextContent());

					EmployeeID = eElement
								.getElementsByTagName("employeeID")
								.item(0)
								.getTextContent();
					System.out.println("EmployeeID : " 
								+ eElement
								.getElementsByTagName("employeeID")
								.item(0)
								.getTextContent());

					TruckNo = eElement
								.getElementsByTagName("truckNo")
								.item(0)
								.getTextContent();
					System.out.println("Truck No. : " 
								+ eElement
								.getElementsByTagName("truckNo")
								.item(0)
								.getTextContent());

					Discount = eElement
								.getElementsByTagName("discount")
								.item(0)
								.getTextContent();
					System.out.println("Discount : " 
								+ eElement
								.getElementsByTagName("discount")
								.item(0)
								.getTextContent());

					Quantity = eElement
								.getElementsByTagName("quantity")
								.item(0)
								.getTextContent();
					System.out.println("Quantity : " 
								+ eElement
								.getElementsByTagName("quantity")
								.item(0)
								.getTextContent());

					UnitPrice = eElement
								.getElementsByTagName("unitPrice")
								.item(0)
								.getTextContent();
					System.out.println("Unit Price : " 
								+ eElement
								.getElementsByTagName("unitPrice")
								.item(0)
								.getTextContent());

					DriverPrice = eElement
								.getElementsByTagName("driverPrice")
								.item(0)
								.getTextContent();
					System.out.println("Driver Price : " 
								+ eElement
								.getElementsByTagName("driverPrice")
								.item(0)
								.getTextContent());

					Vin = eElement
								.getElementsByTagName("VIN")
								.item(0)
								.getTextContent();
					System.out.println("VIN : " 
								+ eElement
								.getElementsByTagName("VIN")
								.item(0)
								.getTextContent());

					RunNumber = eElement
							.getElementsByTagName("runNumber")
							.item(0)
							.getTextContent();
				System.out.println("Run Number : " 
							+ eElement
							.getElementsByTagName("runNumber")
							.item(0)
							.getTextContent());
				
				IsSpecial = eElement
						.getElementsByTagName("isSpecial")
						.item(0)
						.getTextContent();
			System.out.println("Is Special? : " 
						+ eElement
						.getElementsByTagName("isSpecial")
						.item(0)
						.getTextContent());
				
					Rate = eElement
								.getElementsByTagName("rate")
								.item(0)
								.getTextContent();
					System.out.println("Rate : " 
								+ eElement
								.getElementsByTagName("rate")
								.item(0)
								.getTextContent());

					Surcharge = eElement
								.getElementsByTagName("surcharge")
								.item(0)
								.getTextContent();
					System.out.println("Surcharge : " 
								+ eElement
								.getElementsByTagName("surcharge")
								.item(0)
								.getTextContent());

					Dom.insert(TransactionID,OrderID,PriceID,TransactionDate,TransactionDesc,
							TransactionAmount,Make,Model,Year,EmployeeID,TruckNo,Discount,Quantity,UnitPrice,
							DriverPrice,Vin,RunNumber,IsSpecial,Rate,Surcharge);
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}



public int insert(String TransactionID, String OrderID, String PriceID, String TransactionDate, 
		String TransactionDesc, String TransactionAmount, String Make, String Model, String Year, 
		String EmployeeID, String TruckNo, String Discount, String Quantity, String UnitPrice, 
		String DriverPrice, String Vin, String RunNumber, String IsSpecial, String Rate, 
		String Surcharge) throws SQLException
	{		 
		int flag=0;		

		Connection connection=null;
		PreparedStatement preparedStatement = null;

		try
		{                 
			connection=dbConnection.getConnection();
			preparedStatement = (PreparedStatement) connection.prepareStatement("insert into transactions(transactionID,orderID,priceID,transactionDate,transactionDesc,transactionAmount,make,model,year,employeeID,truckNo,discount,quantity,unitPrice,driverPrice,VIN,runNumber,isSpecial,rate,surcharge) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setString(1,TransactionID);
			preparedStatement.setString(2,OrderID);
			preparedStatement.setString(3,PriceID);
			preparedStatement.setString(4,TransactionDate);
			preparedStatement.setString(5,TransactionDesc);
			preparedStatement.setString(6,TransactionAmount);
			preparedStatement.setString(7,Make);
			preparedStatement.setString(8,Model);
			preparedStatement.setString(9,Year);
			preparedStatement.setString(10,EmployeeID);
			preparedStatement.setString(11,TruckNo);
			preparedStatement.setString(12,Discount);
			preparedStatement.setString(13,Quantity);
			preparedStatement.setString(14,UnitPrice);
			preparedStatement.setString(15,DriverPrice);
			preparedStatement.setString(16,Vin);
			preparedStatement.setString(17,RunNumber);
			preparedStatement.setString(18,IsSpecial);
			preparedStatement.setString(19,Rate);
			preparedStatement.setString(20,Surcharge);
			int s = preparedStatement.executeUpdate();
			if(s>0)
				flag=1;
			else
				flag=0;    
		}
		catch (Exception e)
		{
			System.out.println(e);
		}finally
		{
			connection.close();
			preparedStatement.close();
		}
		return flag;
	}
}
