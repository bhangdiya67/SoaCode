package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
public class SaxParserEmployees {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/employees.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			EmployeesHandler employeesHandler = new EmployeesHandler();
			saxParser.parse(inputFile, employeesHandler);     
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
class EmployeesHandler extends DefaultHandler {

	boolean saxEmployeeID = false;
	boolean saxFirstName = false;
	boolean saxLastName = false;
	boolean saxEmailId = false;
	boolean saxExtension = false;
	boolean saxHomePhone = false;
	boolean saxCellPhone = false;
	boolean saxJobTitle = false;
	boolean saxSSN = false;
	boolean saxDriverLicenseNum = false;
	boolean saxStreetAddress = false;
	boolean saxCity = false;
	boolean saxState = false;
	boolean saxPostalCode = false;
	boolean saxDateHired = false;
	boolean saxSalary = false;
	boolean saxBirthDate = false;
	boolean saxNotes = false;

@Override
public void startElement(
		String uri, String localName, String qName, Attributes attributes)
				throws SAXException {

	if (qName.equalsIgnoreCase("employeeID")) {
		saxEmployeeID = true;
	} else if (qName.equalsIgnoreCase("firstName")) {
		saxFirstName = true;
	} else if (qName.equalsIgnoreCase("lastName")) {
		saxLastName = true;
	} else if (qName.equalsIgnoreCase("emailID")) {
		saxEmailId = true;
	} else if (qName.equalsIgnoreCase("extension")) {
		saxExtension = true;
	} else if (qName.equalsIgnoreCase("homePhone")) {
		saxHomePhone = true;
	} else if (qName.equalsIgnoreCase("cellPhone")) {
		saxCellPhone = true;
	} else if (qName.equalsIgnoreCase("jobTitle")) {
		saxJobTitle = true;
	} else if (qName.equalsIgnoreCase("SSN")) {
		saxSSN = true;
	} else if (qName.equalsIgnoreCase("driverLicenseNum")) {
		saxDriverLicenseNum = true;
	} else if (qName.equalsIgnoreCase("streetAddress")) {
		saxStreetAddress = true;
	} else if (qName.equalsIgnoreCase("city")) {
		saxCity = true;
	} else if (qName.equalsIgnoreCase("state")) {
		saxState = true;
	} else if (qName.equalsIgnoreCase("postalCode")) {
		saxPostalCode = true;
	} else if (qName.equalsIgnoreCase("birthDate")) {
		saxBirthDate = true;
	} else if (qName.equalsIgnoreCase("dateHired")) {
		saxDateHired = true;
	} else if (qName.equalsIgnoreCase("salary")) {
		saxSalary = true;
	}  else if (qName.equalsIgnoreCase("notes")) {
		saxNotes = true;
	}
	
}

@Override
public void endElement(String uri, 
		String localName, String qName) throws SAXException {

	if (qName.equalsIgnoreCase("employee")) {
		System.out.println("End Element :" + qName);
		System.out.println("---------------------------------");
	}
}

@Override
public void characters(char ch[], int start, int length) throws SAXException {

	if (saxEmployeeID) {
		System.out.println("Employee ID: " + new String(ch, start, length));
		saxEmployeeID = false;
	} else if (saxFirstName) {
		System.out.println("First Name: " + new String(ch, start, length));
		saxFirstName = false;
	} else if (saxLastName) {
		System.out.println("Last Name: " + new String(ch, start, length));
		saxLastName = false;
	} else if (saxEmailId) {
		System.out.println("Email Id: " + new String(ch, start, length));
		saxEmailId = false;
	} else if (saxExtension) {
		System.out.println("Extension: " + new String(ch, start, length));
		saxExtension = false;
	} else if (saxHomePhone) {
		System.out.println("Home Phone: " + new String(ch, start, length));
		saxHomePhone = false;
	} else if (saxCellPhone) {
		System.out.println("Cell Phone: " + new String(ch, start, length));
		saxCellPhone = false;
	} else if (saxJobTitle) {
		System.out.println("Job Title: " + new String(ch, start, length));
		saxJobTitle = false;
	} else if (saxSSN) {
		System.out.println("Social Security Number: " + new String(ch, start, length));
		saxSSN = false;
	} else if (saxDriverLicenseNum) {
		System.out.println("Driver License Number: " + new String(ch, start, length));
		saxDriverLicenseNum = false;
	} else if (saxStreetAddress) {
		System.out.println("Street Address: " + new String(ch, start, length));
		saxStreetAddress = false;
	} else if (saxCity) {
		System.out.println("City: " + new String(ch, start, length));
		saxCity = false;
	} else if (saxState) {
		System.out.println("State: " + new String(ch, start, length));
		saxState = false;
	} else if (saxPostalCode) {
		System.out.println("Postal Code: " + new String(ch, start, length));
		saxPostalCode = false;
	} else if (saxBirthDate) {
		System.out.println("Birth Date: " + new String(ch, start, length));
		saxBirthDate = false;
	} else if (saxDateHired) {
		System.out.println("Date Hired: " + new String(ch, start, length));
		saxDateHired = false;
	} else if (saxSalary) {
		System.out.println("Salary: " + new String(ch, start, length));
		saxSalary = false;
	} else if (saxNotes) {
		System.out.println("Notes: " + new String(ch, start, length));
		saxNotes = false;
	}
}
}
