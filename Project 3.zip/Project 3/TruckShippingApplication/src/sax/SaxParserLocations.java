package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserLocations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/locations.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			LocationsHandler locationsHandler = new LocationsHandler();
			saxParser.parse(inputFile, locationsHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class LocationsHandler extends DefaultHandler {

	boolean saxLocID = false;
	boolean saxLocName = false;
	boolean saxLocCode = false;
	boolean saxIsAuction = false;
	boolean saxCustomerID = false;
	boolean saxAddressStreet1 = false;
	boolean saxAddressStreet2 = false;
	boolean saxCity = false;
	boolean saxState = false;
	boolean saxPostalCode = false;
	boolean saxCountry = false;
	boolean saxLocContactName = false;
	boolean saxLocPhoneNumber = false;
	boolean saxLocFaxNumber = false;
	boolean saxLocEmail = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("locID")) {
			saxLocID = true;
		} else if (qName.equalsIgnoreCase("locName")) {
			saxLocName = true;
		} else if (qName.equalsIgnoreCase("locCode")) {
			saxLocCode = true;
		} else if (qName.equalsIgnoreCase("isAuction")) {
			saxIsAuction = true;
		} else if (qName.equalsIgnoreCase("customerID")) {
			saxCustomerID = true;
		} else if (qName.equalsIgnoreCase("addressStreet1")) {
			saxAddressStreet1 = true;
		} else if (qName.equalsIgnoreCase("addressStreet2")) {
			saxAddressStreet2 = true;
		} else if (qName.equalsIgnoreCase("city")) {
			saxCity = true;
		} else if (qName.equalsIgnoreCase("state")) {
			saxState = true;
		} else if (qName.equalsIgnoreCase("postalCode")) {
			saxPostalCode = true;
		} else if (qName.equalsIgnoreCase("country")) {
			saxCountry = true;
		} else if (qName.equalsIgnoreCase("locContactName")) {
			saxLocContactName = true;
		} else if (qName.equalsIgnoreCase("locPhoneNumber")) {
			saxLocPhoneNumber = true;
		} else if (qName.equalsIgnoreCase("locFaxNumber")) {
			saxLocFaxNumber = true;
		} else if (qName.equalsIgnoreCase("locEmail")) {
			saxLocEmail = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("location")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxLocID) {
			System.out.println("Location ID: " + new String(ch, start, length));
			saxLocID = false;
		} else if (saxLocName) {
			System.out.println("Location Name: " + new String(ch, start, length));
			saxLocName = false;
		} else if (saxLocCode) {
			System.out.println("Location Code: " + new String(ch, start, length));
			saxLocCode = false;
		} else if (saxIsAuction) {
			System.out.println("Is Auction: " + new String(ch, start, length));
			saxIsAuction = false;
		} else if (saxCustomerID) {
			System.out.println("Customer ID: " + new String(ch, start, length));
			saxCustomerID = false;
		} else if (saxLocCode) {
			System.out.println("Address Street 1: " + new String(ch, start, length));
			saxLocCode = false;
		} else if (saxLocCode) {
			System.out.println("Address Street 2: " + new String(ch, start, length));
			saxLocCode = false;
		} else if (saxCity) {
			System.out.println("City: " + new String(ch, start, length));
			saxCity = false;
		} else if (saxState) {
			System.out.println("State: " + new String(ch, start, length));
			saxState = false;
		} else if (saxPostalCode) {
			System.out.println("Postal Code: " + new String(ch, start, length));
			saxPostalCode = false;
		} else if (saxCountry) {
			System.out.println("Country: " + new String(ch, start, length));
			saxCountry = false;
		} else if (saxLocContactName) {
			System.out.println("Location Contact Name: " + new String(ch, start, length));
			saxLocContactName = false;
		} else if (saxLocPhoneNumber) {
			System.out.println("Location Phone Number: " + new String(ch, start, length));
			saxLocPhoneNumber = false;
		} else if (saxLocFaxNumber) {
			System.out.println("Location Fax Number: " + new String(ch, start, length));
			saxLocFaxNumber = false;
		} else if (saxLocEmail) {
			System.out.println("Location Email: " + new String(ch, start, length));
			saxLocEmail = false;
		}
	}
}
