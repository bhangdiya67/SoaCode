package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserVehicles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/vehicles.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			VehiclesHandler vehiclesHandler = new VehiclesHandler();
			saxParser.parse(inputFile, vehiclesHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class VehiclesHandler extends DefaultHandler {

	boolean saxVehicleID = false;
	boolean saxMake = false;
	boolean saxModel = false;
	boolean saxYear = false;
	boolean saxLicenseplateNo = false;
	boolean saxColor = false;
	boolean saxVIN = false;
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("vehicleID")) {
			saxVehicleID = true;
		} else if (qName.equalsIgnoreCase("make")) {
			saxMake = true;
		} else if (qName.equalsIgnoreCase("model")) {
			saxModel = true;
		} else if (qName.equalsIgnoreCase("year")) {
			saxYear = true;
		} else if (qName.equalsIgnoreCase("licenseplateNo")) {
			saxLicenseplateNo = true;
		} else if (qName.equalsIgnoreCase("color")) {
			saxColor = true;
		} else if (qName.equalsIgnoreCase("VIN")) {
			saxVIN = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("vehicle")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxVehicleID) {
			System.out.println("Vehicle ID: " + new String(ch, start, length));
			saxVehicleID = false;
		} else if (saxMake) {
			System.out.println("Make: " + new String(ch, start, length));
			saxMake = false;
		} else if (saxModel) {
			System.out.println("Model: " + new String(ch, start, length));
			saxModel = false;
		} else if (saxYear) {
			System.out.println("Year: " + new String(ch, start, length));
			saxYear = false;
		} else if (saxLicenseplateNo) {
			System.out.println("License Plate No: " + new String(ch, start, length));
			saxLicenseplateNo = false;
		} else if (saxColor) {
			System.out.println("Color: " + new String(ch, start, length));
			saxColor = false;
		} else if (saxVIN) {
			System.out.println("Vehicle Identification Number: " + new String(ch, start, length));
			saxVIN = false;
		} 
	}
}
