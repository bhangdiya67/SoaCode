package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserPricing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/pricing.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			PricingHandler pricingHandler = new PricingHandler();
			saxParser.parse(inputFile, pricingHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class PricingHandler extends DefaultHandler {

	boolean saxPriceID = false;
	boolean saxLocationIDFrom = false;
	boolean saxLocationIDTo = false;
	boolean saxPrice = false;
	boolean saxLocationCodeFrom = false;
	boolean saxLocationCodeTo = false;
	boolean saxLocationNameFrom = false;
	boolean saxLocationNameTo = false;
	boolean saxCustomerID = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("priceID")) {
			saxPriceID = true;
		} else if (qName.equalsIgnoreCase("locationIDFrom")) {
			saxLocationIDFrom = true;
		} else if (qName.equalsIgnoreCase("locationIDTo")) {
			saxLocationIDTo = true;
		} else if (qName.equalsIgnoreCase("price")) {
			saxPrice = true;
		} else if (qName.equalsIgnoreCase("locationCodeFrom")) {
			saxLocationCodeFrom = true;
		} else if (qName.equalsIgnoreCase("locationCodeTo")) {
			saxLocationCodeTo = true;
		} else if (qName.equalsIgnoreCase("locationNameFrom")) {
			saxLocationNameFrom = true;
		} else if (qName.equalsIgnoreCase("locationNameTo")) {
			saxLocationNameTo = true;
		} else if (qName.equalsIgnoreCase("customerID")) {
			saxCustomerID = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("shippingCost")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxPriceID) {
			System.out.println("Price ID: " + new String(ch, start, length));
			saxPriceID = false;
		} else if (saxLocationIDFrom) {
			System.out.println("Location ID From: " + new String(ch, start, length));
			saxLocationIDFrom = false;
		} else if (saxLocationIDTo) {
			System.out.println("Location ID To: " + new String(ch, start, length));
			saxLocationIDTo = false;
		} else if (saxPrice) {
			System.out.println("Price: " + new String(ch, start, length));
			saxPrice = false;
		} else if (saxLocationCodeFrom) {
			System.out.println("Location Code From: " + new String(ch, start, length));
			saxLocationCodeFrom = false;
		} else if (saxLocationCodeTo) {
			System.out.println("Location Code To: " + new String(ch, start, length));
			saxLocationCodeTo = false;
		} else if (saxLocationNameFrom) {
			System.out.println("Location Name From: " + new String(ch, start, length));
			saxLocationNameFrom = false;
		} else if (saxLocationNameTo) {
			System.out.println("Location Name TO: " + new String(ch, start, length));
			saxLocationNameTo = false;
		} else if (saxCustomerID) {
			System.out.println("Customer ID: " + new String(ch, start, length));
			saxCustomerID = false;
		}
	}
}
