package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserComments {

	public static void main(String[] args) {
		try {
			File inputFile = new File("XML/comments.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			CommentsHandler commentsHandler = new CommentsHandler();
			saxParser.parse(inputFile, commentsHandler);     
		} catch (Exception e) {
			e.printStackTrace();
		}
	}   
}
class CommentsHandler extends DefaultHandler {

	boolean saxCommentID = false;
	boolean saxCommentTime = false;
	boolean saxCommentDate = false;
	boolean saxComment = false;
	boolean saxType = false;

	@Override
	public void startElement(
			String uri, String localName, String qName, Attributes attributes)
					throws SAXException {

		if (qName.equalsIgnoreCase("commentID")) {
			saxCommentID = true;
		} else if (qName.equalsIgnoreCase("commentTime")) {
			saxCommentTime = true;
		} else if (qName.equalsIgnoreCase("commentDate")) {
			saxCommentDate = true;
		} else if (qName.equalsIgnoreCase("description")) {
			saxComment = true;
		}
		else if (qName.equalsIgnoreCase("type")) {
			saxType = true;
		}
	}

	@Override
	public void endElement(String uri, 
			String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("comment")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxCommentID) {
			System.out.println("Comment ID: " + new String(ch, start, length));
			saxCommentID = false;
		} else if (saxCommentTime) {
			System.out.println("Comment Time: " + new String(ch, start, length));
			saxCommentTime = false;
		} else if (saxCommentDate) {
			System.out.println("Comment Date: " + new String(ch, start, length));
			saxCommentDate = false;
		} else if (saxComment) {
			System.out.println("Comment: " + new String(ch, start, length));
			saxComment = false;
		}else if (saxType) {
			System.out.println("Type: " + new String(ch, start, length));
			saxType = false;
		}
	}
}




