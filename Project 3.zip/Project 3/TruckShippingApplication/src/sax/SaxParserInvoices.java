package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserInvoices {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/invoices.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			InvoicesHandler invoicesHandler = new InvoicesHandler();
			saxParser.parse(inputFile, invoicesHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class InvoicesHandler extends DefaultHandler {

	boolean saxInvoiceID = false;
	boolean saxOrderID = false;
	boolean saxEmployeeID = false;
	boolean saxCustomerID = false;
	boolean saxInvoiceAmount = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("invoiceID")) {
			saxInvoiceID = true;
		} else if (qName.equalsIgnoreCase("orderID")) {
			saxOrderID = true;
		} else if (qName.equalsIgnoreCase("employeeID")) {
			saxEmployeeID = true;
		} else if (qName.equalsIgnoreCase("customerID")) {
			saxCustomerID = true;
		} else if (qName.equalsIgnoreCase("invoiceAmount")) {
			saxInvoiceAmount = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("invoice")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxInvoiceID) {
			System.out.println("Invoice ID: " + new String(ch, start, length));
			saxInvoiceID = false;
		} else if (saxOrderID) {
			System.out.println("Order ID: " + new String(ch, start, length));
			saxOrderID = false;
		} else if (saxEmployeeID) {
			System.out.println("Employee ID: " + new String(ch, start, length));
			saxEmployeeID = false;
		} else if (saxCustomerID) {
			System.out.println("Customer ID: " + new String(ch, start, length));
			saxCustomerID = false;
		} else if (saxInvoiceAmount) {
			System.out.println("Invoice Amount: " + new String(ch, start, length));
			saxInvoiceAmount = false;
		}
	}
}
