package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserTransactions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/transactions.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			TransactionsHandler transactionsHandler = new TransactionsHandler();
			saxParser.parse(inputFile, transactionsHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class TransactionsHandler extends DefaultHandler {

	boolean saxTransactionID = false;
	boolean saxOrderID = false;
	boolean saxPriceID = false;
	boolean saxTransactionDate = false;
	boolean saxTransactionDesc = false;
	boolean saxTransactionAmount = false;
	boolean saxMake = false;
	boolean saxModel = false;
	boolean saxYear = false;
	boolean saxEmployeeID = false;
	boolean saxTruckNo = false;
	boolean saxDiscount = false; 
	boolean saxQuantity = false;
	boolean saxUnitPrice  = false;
	boolean saxDriverPrice  = false;
	boolean saxVIN  = false;
	boolean saxRunNumber = false;
	boolean saxIsSpecial  = false;
	boolean saxRate  = false;
	boolean saxSurcharge = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("transactionID")) {
			saxTransactionID = true;
		} else if (qName.equalsIgnoreCase("orderID")) {
			saxOrderID = true;
		} else if (qName.equalsIgnoreCase("priceID")) {
			saxPriceID = true;
		} else if (qName.equalsIgnoreCase("transactionDate")) {
			saxTransactionDate = true;
		} else if (qName.equalsIgnoreCase("transactionDesc")) {
			saxTransactionDesc = true;
		} else if (qName.equalsIgnoreCase("transactionAmount")) {
			saxTransactionAmount = true;
		} else if (qName.equalsIgnoreCase("make")) {
			saxMake = true;
		} else if (qName.equalsIgnoreCase("model")) {
			saxModel = true;
		} else if (qName.equalsIgnoreCase("year")) {
			saxYear = true;
		} else if (qName.equalsIgnoreCase("employeeID")) {
			saxEmployeeID = true;
		} else if (qName.equalsIgnoreCase("truckNo")) {
			saxTruckNo = true;
		} else if (qName.equalsIgnoreCase("discount")) {
			saxDiscount = true;
		} else if (qName.equalsIgnoreCase("quantity")) {
			saxQuantity = true;
		} else if (qName.equalsIgnoreCase("unitPrice")) {
			saxUnitPrice = true;
		} else if (qName.equalsIgnoreCase("driverPrice")) {
			saxDriverPrice = true;
		} else if (qName.equalsIgnoreCase("VIN")) {
			saxVIN = true;
		} else if (qName.equalsIgnoreCase("runNumber")) {
			saxRunNumber = true;
		} else if (qName.equalsIgnoreCase("isSpecial")) {
			saxIsSpecial = true;
		} else if (qName.equalsIgnoreCase("rate")) {
			saxRate = true;
		} else if (qName.equalsIgnoreCase("surcharge")) {
			saxSurcharge = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("transaction")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxTransactionID) {
			System.out.println("Transaction ID: " + new String(ch, start, length));
			saxTransactionID = false;
		} else if (saxOrderID) {
			System.out.println("Order ID: " + new String(ch, start, length));
			saxOrderID = false;
		} else if (saxPriceID) {
			System.out.println("Price ID: " + new String(ch, start, length));
			saxPriceID = false;
		} else if (saxTransactionDate) {
			System.out.println("Transaction Date: " + new String(ch, start, length));
			saxTransactionDate = false;
		} else if (saxTransactionDesc) {
			System.out.println("Transaction Description: " + new String(ch, start, length));
			saxTransactionDesc = false;
		} else if (saxTransactionAmount) {
			System.out.println("Transaction Amount: " + new String(ch, start, length));
			saxTransactionAmount = false;
		} else if (saxMake) {
			System.out.println("Make: " + new String(ch, start, length));
			saxMake = false;
		} else if (saxModel) {
			System.out.println("Model: " + new String(ch, start, length));
			saxModel = false;
		} else if (saxYear) {
			System.out.println("Year: " + new String(ch, start, length));
			saxYear = false;
		} else if (saxEmployeeID) {
			System.out.println("Employee ID: " + new String(ch, start, length));
			saxEmployeeID = false;
		} else if (saxTruckNo) {
			System.out.println("Truck No: " + new String(ch, start, length));
			saxTruckNo = false;
		} else if (saxDiscount) {
			System.out.println("Discount: " + new String(ch, start, length));
			saxDiscount = false;
		} else if (saxQuantity) {
			System.out.println("Quantity: " + new String(ch, start, length));
			saxQuantity = false;
		} else if (saxUnitPrice) {
			System.out.println("Unit Price: " + new String(ch, start, length));
			saxUnitPrice = false;
		} else if (saxDriverPrice) {
			System.out.println("Driver Price: " + new String(ch, start, length));
			saxDriverPrice = false;
		} else if (saxVIN) {
			System.out.println("Vehicle Identification Number: " + new String(ch, start, length));
			saxVIN = false;
		} else if (saxRunNumber) {
			System.out.println("Run Number: " + new String(ch, start, length));
			saxRunNumber = false;
		} else if (saxIsSpecial) {
			System.out.println("Is Special?: " + new String(ch, start, length));
			saxIsSpecial = false;
		} else if (saxRate) {
			System.out.println("Rate: " + new String(ch, start, length));
			saxRate = false;
		} else if (saxSurcharge) {
			System.out.println("Surcharge: " + new String(ch, start, length));
			saxSurcharge = false;
		}
	}
}
