package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserOrders {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/orders.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			OrdersHandler ordersHandler = new OrdersHandler();
			saxParser.parse(inputFile, ordersHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class OrdersHandler extends DefaultHandler {

	boolean saxOrderID = false;
	boolean saxOrderDate = false;
	boolean saxCustomerID = false;
	boolean saxEmployeeID = false;
	boolean saxTruckNo = false;
	boolean saxIsSpecial = false;
	boolean saxPON = false;
	boolean saxOrderTotalAmount = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("orderID")) {
			saxOrderID = true;
		} else if (qName.equalsIgnoreCase("orderDate")) {
			saxOrderDate = true;
		} else if (qName.equalsIgnoreCase("customerID")) {
			saxCustomerID = true;
		} else if (qName.equalsIgnoreCase("employeeID")) {
			saxEmployeeID = true;
		} else if (qName.equalsIgnoreCase("truckNo")) {
			saxTruckNo = true;
		} else if (qName.equalsIgnoreCase("isSpecial")) {
			saxIsSpecial = true;
		} else if (qName.equalsIgnoreCase("pON")) {
			saxPON = true;
		} else if (qName.equalsIgnoreCase("orderTotalAmount")) {
			saxOrderTotalAmount = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("order")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxOrderID) {
			System.out.println("Order ID: " + new String(ch, start, length));
			saxOrderID = false;
		} else if (saxOrderDate) {
			System.out.println("Order Date: " + new String(ch, start, length));
			saxOrderDate = false;
		} else if (saxCustomerID) {
			System.out.println("Customer ID: " + new String(ch, start, length));
			saxCustomerID = false;
		} else if (saxEmployeeID) {
			System.out.println("Employee ID: " + new String(ch, start, length));
			saxEmployeeID = false;
		} else if (saxTruckNo) {
			System.out.println("Truck No: " + new String(ch, start, length));
			saxTruckNo = false;
		} else if (saxIsSpecial) {
			System.out.println("Is Special: " + new String(ch, start, length));
			saxIsSpecial = false;
		} else if (saxPON) {
			System.out.println("Purchase Order Number: " + new String(ch, start, length));
			saxPON = false;
		} else if (saxOrderTotalAmount) {
			System.out.println("Order Total Amount: " + new String(ch, start, length));
			saxOrderTotalAmount = false;
		}
	}
}
