package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserTickets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/tickets.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			TicketsHandler ticketsHandler = new TicketsHandler();
			saxParser.parse(inputFile, ticketsHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class TicketsHandler extends DefaultHandler {

	boolean saxTicketID = false;
	boolean saxEmployeeID = false;
	boolean saxTicketDate = false;
	boolean saxReason = false;
	boolean saxAmount = false;
	boolean saxIsPaid = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("ticketID")) {
			saxTicketID = true;
		} else if (qName.equalsIgnoreCase("employeeID")) {
			saxEmployeeID = true;
		} else if (qName.equalsIgnoreCase("ticketDate")) {
			saxTicketDate = true;
		} else if (qName.equalsIgnoreCase("reason")) {
			saxReason = true;
		} else if (qName.equalsIgnoreCase("amount")) {
			saxAmount = true;
		} else if (qName.equalsIgnoreCase("isPaid")) {
			saxIsPaid = true;
		} 
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("ticket")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxTicketID) {
			System.out.println("Ticket ID: " + new String(ch, start, length));
			saxTicketID = false;
		} else if (saxEmployeeID) {
			System.out.println("Employee ID: " + new String(ch, start, length));
			saxEmployeeID = false;
		} else if (saxTicketDate) {
			System.out.println("Ticket Date: " + new String(ch, start, length));
			saxTicketDate = false;
		} else if (saxReason) {
			System.out.println("Reason: " + new String(ch, start, length));
			saxReason = false;
		} else if (saxAmount) {
			System.out.println("Amount: " + new String(ch, start, length));
			saxAmount = false;
		} else if (saxIsPaid) {
			System.out.println("Is Paid?: " + new String(ch, start, length));
			saxIsPaid = false;
		} 
	}

}
