package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserExpenses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/expenses.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			ExpensesHandler expensesHandler = new ExpensesHandler();
			saxParser.parse(inputFile, expensesHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class ExpensesHandler extends DefaultHandler {

	boolean saxExpenseID = false;
	boolean saxEmployeeID = false;
	boolean saxExpenseType = false;
	boolean saxPurposeofExpense = false;
	boolean saxAmountSpent = false;
	boolean saxDescription = false;
	boolean saxDatePurchased = false;
	boolean saxDateSubmitted = false;
	boolean saxAdvanceAmount = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("expenseID")) {
			saxExpenseID = true;
		} else if (qName.equalsIgnoreCase("employeeID")) {
			saxEmployeeID = true;
		} else if (qName.equalsIgnoreCase("expenseType")) {
			saxExpenseType = true;
		} else if (qName.equalsIgnoreCase("purposeofExpense")) {
			saxPurposeofExpense = true;
		} else if (qName.equalsIgnoreCase("amountSpent")) {
			saxAmountSpent = true;
		} else if (qName.equalsIgnoreCase("description")) {
			saxDescription = true;
		} else if (qName.equalsIgnoreCase("datePurchased")) {
			saxDatePurchased = true;
		} else if (qName.equalsIgnoreCase("dateSubmitted")) {
			saxDateSubmitted = true;
		} else if (qName.equalsIgnoreCase("advanceAmount")) {
			saxAdvanceAmount = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("expense")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxExpenseID) {
			System.out.println("Expense ID: " + new String(ch, start, length));
			saxExpenseID = false;
		} else if (saxEmployeeID) {
			System.out.println("Employee ID: " + new String(ch, start, length));
			saxEmployeeID = false;
		} else if (saxExpenseType) {
			System.out.println("Expense Type: " + new String(ch, start, length));
			saxExpenseType = false;
		} else if (saxPurposeofExpense) {
			System.out.println("Purpose of Expense: " + new String(ch, start, length));
			saxPurposeofExpense = false;
		} else if (saxAmountSpent) {
			System.out.println("Amount Spent: " + new String(ch, start, length));
			saxAmountSpent = false;
		} else if (saxDescription) {
			System.out.println("Description: " + new String(ch, start, length));
			saxDescription = false;
		} else if (saxDatePurchased) {
			System.out.println("Date Purchased: " + new String(ch, start, length));
			saxDatePurchased = false;
		} else if (saxDateSubmitted) {
			System.out.println("Date Submitted: " + new String(ch, start, length));
			saxDateSubmitted = false;
		} else if (saxAdvanceAmount) {
			System.out.println("Advance Amount: " + new String(ch, start, length));
			saxAdvanceAmount = false;
		}
	}
}
