package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserTrucks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/trucks.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			TrucksHandler trucksHandler = new TrucksHandler();
			saxParser.parse(inputFile, trucksHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class TrucksHandler extends DefaultHandler {

	boolean saxTruckNo = false;
	boolean saxMake = false;
	boolean saxModel = false;
	boolean saxYear = false;
	boolean saxLicenseplateNo = false;
	boolean saxEmployeeID = false;
	boolean saxColor = false;
	boolean saxVIN = false;
	boolean saxTruckCost = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("truckNo")) {
			saxTruckNo = true;
		} else if (qName.equalsIgnoreCase("make")) {
			saxMake = true;
		} else if (qName.equalsIgnoreCase("model")) {
			saxModel = true;
		} else if (qName.equalsIgnoreCase("year")) {
			saxYear = true;
		} else if (qName.equalsIgnoreCase("licenseplateNo")) {
			saxLicenseplateNo = true;
		} else if (qName.equalsIgnoreCase("employeeID")) {
			saxEmployeeID = true;
		} else if (qName.equalsIgnoreCase("color")) {
			saxColor = true;
		} else if (qName.equalsIgnoreCase("VIN")) {
			saxVIN = true;
		} else if (qName.equalsIgnoreCase("truckCost")) {
			saxTruckCost = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("truck")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxTruckNo) {
			System.out.println("Truck No: " + new String(ch, start, length));
			saxTruckNo = false;
		} else if (saxMake) {
			System.out.println("Make: " + new String(ch, start, length));
			saxMake = false;
		} else if (saxModel) {
			System.out.println("Model: " + new String(ch, start, length));
			saxModel = false;
		} else if (saxYear) {
			System.out.println("Year: " + new String(ch, start, length));
			saxYear = false;
		} else if (saxLicenseplateNo) {
			System.out.println("License Plate No: " + new String(ch, start, length));
			saxLicenseplateNo = false;
		} else if (saxEmployeeID) {
			System.out.println("Employee ID: " + new String(ch, start, length));
			saxEmployeeID = false;
		} else if (saxColor) {
			System.out.println("Color: " + new String(ch, start, length));
			saxColor = false;
		} else if (saxVIN) {
			System.out.println("Vehicle Identification Number: " + new String(ch, start, length));
			saxVIN = false;
		} else if (saxTruckCost) {
			System.out.println("Truck Cost: " + new String(ch, start, length));
			saxTruckCost = false;
		}
	}
}
