package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserPayments {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/payments.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			PaymentsHandler paymentsHandler = new PaymentsHandler();
			saxParser.parse(inputFile, paymentsHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class PaymentsHandler extends DefaultHandler {

	boolean saxPaymentID = false;
	boolean saxOrderID = false;
	boolean saxTransactionID = false;
	boolean saxPaymentMethodID = false;
	boolean saxPaymentAmount = false;
	boolean saxPaymentDate = false;
	boolean saxCheckNumber = false;
	boolean saxCreditCardNumber = false;
	boolean saxCardholdersName = false;
	boolean saxCreditCardExpDate = false;
	boolean saxCVV = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		if (qName.equalsIgnoreCase("paymentID")) {
			saxPaymentID = true;
		} else if (qName.equalsIgnoreCase("orderID")) {
			saxOrderID = true;
		} else if (qName.equalsIgnoreCase("transactionID")) {
			saxTransactionID = true;
		} else if (qName.equalsIgnoreCase("paymentMethodID")) {
			saxPaymentMethodID = true;
		} else if (qName.equalsIgnoreCase("paymentAmount")) {
			saxPaymentAmount = true;
		} else if (qName.equalsIgnoreCase("paymentDate")) {
			saxPaymentDate = true;
		} else if (qName.equalsIgnoreCase("checkNumber")) {
			saxCheckNumber = true;
		} else if (qName.equalsIgnoreCase("creditCardNumber")) {
			saxCreditCardNumber = true;
		} else if (qName.equalsIgnoreCase("cardholdersName")) {
			saxCardholdersName = true;
		} else if (qName.equalsIgnoreCase("creditCardExpDate")) {
			saxCreditCardExpDate = true;
		} else if (qName.equalsIgnoreCase("cVV")) {
			saxCVV = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("payment")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxPaymentID) {
			System.out.println("Payment ID: " + new String(ch, start, length));
			saxPaymentID = false;
		} else if (saxOrderID) {
			System.out.println("Order ID: " + new String(ch, start, length));
			saxOrderID = false;
		} else if (saxTransactionID) {
			System.out.println("Transaction ID: " + new String(ch, start, length));
			saxTransactionID = false;
		} else if (saxPaymentMethodID) {
			System.out.println("Payment Method ID: " + new String(ch, start, length));
			saxPaymentMethodID = false;
		} else if (saxPaymentAmount) {
			System.out.println("Payment Amount: " + new String(ch, start, length));
			saxPaymentAmount = false;
		} else if (saxPaymentDate) {
			System.out.println("Payment Date: " + new String(ch, start, length));
			saxPaymentDate = false;
		} else if (saxCheckNumber) {
			System.out.println("Check Number: " + new String(ch, start, length));
			saxCheckNumber = false;
		} else if (saxCreditCardNumber) {
			System.out.println("Credit Card Number: " + new String(ch, start, length));
			saxCreditCardNumber = false;
		} else if (saxCardholdersName) {
			System.out.println("Card Holders Name: " + new String(ch, start, length));
			saxCardholdersName = false;
		} else if (saxCreditCardExpDate) {
			System.out.println("Credit Card Expiry Date: " + new String(ch, start, length));
			saxCreditCardExpDate = false;
		} else if (saxCVV) {
			System.out.println("CVV: " + new String(ch, start, length));
			saxCVV = false;
		}
	}
}
