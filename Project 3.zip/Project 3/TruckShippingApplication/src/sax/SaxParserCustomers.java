package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserCustomers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File inputFile = new File("XML/customers.xml");
			SAXParserFactory saxParserfactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxParserfactory.newSAXParser();
			CustomerHandler customerHandler = new CustomerHandler();
			saxParser.parse(inputFile, customerHandler);     
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
class CustomerHandler extends DefaultHandler {

	boolean saxCustomerID = false;
	boolean saxCustomerTitle = false;
	boolean saxBusinessName = false;
	boolean saxBillingAddress = false;
	boolean saxCity = false;
	boolean saxState = false;
	boolean saxPostalCode = false;
	boolean saxCountry = false;
	boolean saxPhoneNumber = false;
	boolean saxEmailID = false;
	boolean saxType = false;
	boolean saxCellNumber = false;
	boolean saxFaxNumber = false;
	boolean saxCompanyName = false;
	boolean saxContactName = false;
	boolean saxAlternateContactName = false;
	boolean saxDateEntered = false;

	@Override
	public void startElement(
			String uri, String localName, String qName, Attributes attributes)
					throws SAXException {

		if (qName.equalsIgnoreCase("customerID")) {
			saxCustomerID = true;
		} else if (qName.equalsIgnoreCase("customerTitle")) {
			saxCustomerTitle = true;
		} else if (qName.equalsIgnoreCase("businessName")) {
			saxBusinessName = true;
		} else if (qName.equalsIgnoreCase("billingAddress")) {
			saxBillingAddress = true;
		} else if (qName.equalsIgnoreCase("city")) {
			saxCity = true;
		} else if (qName.equalsIgnoreCase("state")) {
			saxState = true;
		} else if (qName.equalsIgnoreCase("postalCode")) {
			saxPostalCode = true;
		} else if (qName.equalsIgnoreCase("country")) {
			saxCountry = true;
		} else if (qName.equalsIgnoreCase("phoneNumber")) {
			saxPhoneNumber = true;
		} else if (qName.equalsIgnoreCase("emailID")) {
			saxEmailID = true;
		} else if (qName.equalsIgnoreCase("type")) {
			saxType = true;
		} else if (qName.equalsIgnoreCase("cellNumber")) {
			saxCellNumber = true;
		} else if (qName.equalsIgnoreCase("faxNumber")) {
			saxFaxNumber = true;
		} else if (qName.equalsIgnoreCase("companyName")) {
			saxCompanyName = true;
		} else if (qName.equalsIgnoreCase("contactName")) {
			saxContactName = true;
		} else if (qName.equalsIgnoreCase("alternateContactName")) {
			saxAlternateContactName = true;
		} else if (qName.equalsIgnoreCase("dateEntered")) {
			saxDateEntered = true;
		}          
		
	}

	@Override
	public void endElement(String uri, 
			String localName, String qName) throws SAXException {

		if (qName.equalsIgnoreCase("customer")) {
			System.out.println("End Element :" + qName);
			System.out.println("---------------------------------");
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {

		if (saxCustomerID) {
			System.out.println("Customer ID: " + new String(ch, start, length));
			saxCustomerID = false;
		} else if (saxCustomerTitle) {
			System.out.println("Customer Title: " + new String(ch, start, length));
			saxCustomerTitle = false;
		} else if (saxBusinessName) {
			System.out.println("Business Name: " + new String(ch, start, length));
			saxBusinessName = false;
		} else if (saxBillingAddress) {
			System.out.println("Billing Address: " + new String(ch, start, length));
			saxBillingAddress = false;
		} else if (saxCity) {
			System.out.println("City: " + new String(ch, start, length));
			saxCity = false;
		} else if (saxState) {
			System.out.println("State: " + new String(ch, start, length));
			saxState = false;
		} else if (saxPostalCode) {
			System.out.println("Postal Code: " + new String(ch, start, length));
			saxPostalCode = false;
		} else if (saxCountry) {
			System.out.println("Country: " + new String(ch, start, length));
			saxCountry = false;
		} else if (saxPhoneNumber) {
			System.out.println("Phone Number: " + new String(ch, start, length));
			saxPhoneNumber = false;
		} else if (saxEmailID) {
			System.out.println("Email ID: " + new String(ch, start, length));
			saxEmailID = false;
		} else if (saxType) {
			System.out.println("Type: " + new String(ch, start, length));
			saxType = false;
		} else if (saxCellNumber) {
			System.out.println("Cell Number: " + new String(ch, start, length));
			saxCellNumber = false;
		} else if (saxFaxNumber) {
			System.out.println("Fax Number: " + new String(ch, start, length));
			saxFaxNumber = false;
		} else if (saxCompanyName) {
			System.out.println("Company Name: " + new String(ch, start, length));
			saxCompanyName = false;
		} else if (saxContactName) {
			System.out.println("Contact Name: " + new String(ch, start, length));
			saxContactName = false;
		} else if (saxAlternateContactName) {
			System.out.println("Alternate Contact Name: " + new String(ch, start, length));
			saxAlternateContactName = false;
		} else if (saxDateEntered) {
			System.out.println("Date Entered: " + new String(ch, start, length));
			saxDateEntered = false;
		} 
	}
}


