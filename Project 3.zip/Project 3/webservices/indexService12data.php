<html>
<body>
<head>
    <style>
        table
        {
            width: 100%;
            border-collapse: collapse;
        }

        table, td, th 
        {
            border: 1px solid black;
            padding: 5px;
        }

        th {text-align: left;}
    </style>
</head>
<body>
    </style>
</head>
<?php
    require "dbConnect.php";
    $q = $_REQUEST["q"];
    if(empty($q))exit;
    $sql = "SELECT * FROM locations WHERE customerID ='".$q."'";
    
    $result = mysqli_query($conn, $sql);
    echo "<table class='table table-bordered no-margin'>
    <tr>
    <th>Location</th>
    <th>Code</th>
    <th>Auction</th>
    <th>StreetAddress1</th>
    <th>StreetAddress2</th>
    <th>City</th>
    <th>State</th>
    <th>PostalCode</th>
    <th>Country</th>
    <th>ContactName</th>
    <th>Phonenumber</th>
    <th>Faxnumber</th>
    <th>Email</th>
    </tr>";

    while($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['locName'] . "</td>";
        echo "<td>" . $row['locCode'] . "</td>";
        echo "<td>" . $row['isAuction'] . "</td>";
        echo "<td>" . $row['addressStreet1'] . "</td>";
        echo "<td>" . $row['addressStreet2'] . "</td>";
        echo "<td>" . $row['city'] . "</td>";
        echo "<td>" . $row['state'] . "</td>";
        echo "<td>" . $row['postalCode'] . "</td>";
        echo "<td>" . $row['country'] . "</td>";
        echo "<td>" . $row['locContactName'] . "</td>";
        echo "<td>" . $row['locPhoneNumber'] . "</td>";
        echo "<td>" . $row['locFaxNumber'] . "</td>";
        echo "<td>" . $row['locEmail'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
   
    
?>
</body>
</html>