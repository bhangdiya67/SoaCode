<?php
    require "dbConnect.php";
    $sql = "SELECT DISTINCTROW year FROM vehicles";
    
    $result = mysqli_query($conn, $sql);
    

    if (mysqli_num_rows($result) > 0)
     {
        // output data of each row
        echo "<form>";
        echo "<div class='form-group'><select class=form-control name=Vehicles onchange=vehicleData(this.value)>";
        echo"<option value='0'>Select Year of Vehicle</option>";
        while($row = mysqli_fetch_assoc($result))
         {
           echo"<option>$row[year]</option>";
        }
        echo "</select></div>";
        echo "</form>";
    } 
    else 
    {
        echo "0 results";
    }

    
    
?>