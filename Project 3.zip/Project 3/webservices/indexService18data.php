<html>
<body>
<head>
    <style>
        table
        {
            width: 100%;
            border-collapse: collapse;
        }

        table, td, th 
        {
            border: 1px solid black;
            padding: 5px;
        }

        th {text-align: left;}
    </style>
</head>
<body>
    </style>
</head>
<?php
    require "dbConnect.php";
    $q = $_REQUEST["q"];
    if(empty($q))exit;
    $sql = "SELECT * FROM transactions WHERE discount ='".$q."'";
    
    $result = mysqli_query($conn, $sql);
    echo "<table class='table table-bordered no-margin'>
    <tr>
    <th>transactionID</th>
    <th>orderID</th>
    <th>TransactionDate</th>
    <th>Description</th>
    <th>TransactionAmount</th>
    <th>make</th>
    <th>model</th>
    <th>year</th>
    <th>quantity</th>
    <th>unitprice</th>
    <th>DriverPrice</th>
    <th>Rate</th>
    <th>Surcharge</th>
    </tr>";

    while($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['transactionID'] . "</td>";
        echo "<td>" . $row['orderID'] . "</td>";
        echo "<td>" . $row['transactionDate'] . "</td>";
        echo "<td>" . $row['transactionDesc'] . "</td>";
        echo "<td>" . $row['transactionAmount'] . "</td>";
        echo "<td>" . $row['make'] . "</td>";
        echo "<td>" . $row['model'] . "</td>";
        echo "<td>" . $row['year'] . "</td>";
        echo "<td>" . $row['quantity'] . "</td>";
        echo "<td>" . $row['unitprice'] . "</td>";
        echo "<td>" . $row['driverprice'] . "</td>";
        echo "<td>" . $row['rate'] . "</td>";
        echo "<td>" . $row['surcharge'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
?>
</body>
</html>