<?php
    require "dbConnect.php";
    $sql = "SELECT customerID FROM customers";
    
    $result = mysqli_query($conn, $sql);
    

    if (mysqli_num_rows($result) > 0)
     {
        // output data of each row
        echo "<form>";
        echo "<div class='form-group'><select class=form-control name=Order onchange=getOrderID(this.value)>";
        echo"<option value='0'>Select Orders Customer ID</option>";
        while($row = mysqli_fetch_assoc($result))
         {
           echo"<option>$row[customerID]</option>";
        }
        echo "</select></div>";
        echo "</form>";
    } 
    else 
    {
        echo "0 results";
    }

    
    
?>