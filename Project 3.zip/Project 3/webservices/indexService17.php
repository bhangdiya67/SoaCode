<?php
    require "dbConnect.php";
    $sql = "SELECT DISTINCTROW priceID FROM pricing";
    
    $result = mysqli_query($conn, $sql);
    

    if (mysqli_num_rows($result) > 0)
     {
        // output data of each row
        echo "<form>";
        echo "<div class='form-group'><select class=form-control name=prices onchange=getPricing(this.value)>";
        echo"<option value='0'>Select PriceID </option>";
        while($row = mysqli_fetch_assoc($result))
         {
           echo"<option>$row[priceID]</option>";
        }
        echo "</select></div>";
        echo "</form>";
    } 
    else 
    {
        echo "0 results";
    }

    
    
?>