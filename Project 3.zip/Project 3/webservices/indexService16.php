<?php
    require "dbConnect.php";
    $sql = "SELECT salary FROM employees WHERE salary<5000";
    
    $result = mysqli_query($conn, $sql);
    

    if (mysqli_num_rows($result) > 0)
     {
        // output data of each row
        echo "<form>";
        echo "<div class='form-group'><select class=form-control name=salaries onchange=getSalaries(this.value)>";
        echo"<option value='0'>Salaries <5000</option>";
        while($row = mysqli_fetch_assoc($result))
         {
           echo"<option>$row[salary]</option>";
        }
        echo "</select></div>";
        echo "</form>";
    } 
    else 
    {
        echo "0 results";
    }

    
    
?>