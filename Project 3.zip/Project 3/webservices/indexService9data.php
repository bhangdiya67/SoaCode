<html>
<body>
<head>
    <style>
        table
        {
            width: 100%;
            border-collapse: collapse;
        }

        table, td, th 
        {
            border: 1px solid black;
            padding: 5px;
        }

        th {text-align: left;}
    </style>
</head>
<body>
    </style>
</head>
<?php
    require "dbConnect.php";
    $q = $_REQUEST["q"];
    if(empty($q))exit;
    $sql = "SELECT * FROM invoices WHERE employeeID ='".$q."'";
    
    $result = mysqli_query($conn, $sql);
    echo "<table class='table table-bordered no-margin'>
    <tr>
    <th>InvoiceID</th>
    <th>OrderID</th>
    <th>EmployeeID</th>
    <th>CustomerID</th>
    <th>invoiceAmaount</th>
    </tr>";

    while($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['invoiceID'] . "</td>";
        echo "<td>" . $row['orderID'] . "</td>";
        echo "<td>" . $row['employeeID'] . "</td>";
        echo "<td>" . $row['customerID'] . "</td>";
        echo "<td>" . $row['invoiceAmount'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
   
    
?>
</body>
</html>