<html>
<body>
<head>
    <style>
        table
        {
            width: 100%;
            border-collapse: collapse;
        }

        table, td, th 
        {
            border: 1px solid black;
            padding: 5px;
        }

        th {text-align: left;}
    </style>
</head>
<body>
    </style>
</head>
<?php
    require "dbConnect.php";
    $q = $_REQUEST["q"];
    if(empty($q))exit;
    $sql = "SELECT * FROM expenses WHERE employeeID ='".$q."'";
    
    $result = mysqli_query($conn, $sql);
    echo "<table class='table table-bordered no-margin'>
    <tr>
    <th>expenseID</th>
    <th>employeeID</th>
    <th>expenseType</th>
    <th>purposeOFExpense</th>
    <th>AmountSpent</th>
    <th>description</th>
    <th>datePurchased</th>
    <th>dateSubmitted</th>
    <th>advanceAmount</th>
    <th>paymentMethod</th>
    </tr>";

    while($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['expenseID'] . "</td>";
        echo "<td>" . $row['employeeID'] . "</td>";
        echo "<td>" . $row['expenseType'] . "</td>";
        echo "<td>" . $row['purposeofExpense'] . "</td>";
        echo "<td>" . $row['amountSpent'] . "</td>";
        echo "<td>" . $row['description'] . "</td>";
        echo "<td>" . $row['datePurchased'] . "</td>";
        echo "<td>" . $row['dateSubmitted'] . "</td>";
        echo "<td>" . $row['advanceAmount'] . "</td>";
        echo "<td>" . $row['paymentMethod'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
?>
</body>
</html>