<html>
<body>
<head>
    <style>
        table
        {
            width: 100%;
            border-collapse: collapse;
        }

        table, td, th 
        {
            border: 1px solid black;
            padding: 5px;
        }

        th {text-align: left;}
    </style>
        
</head>
<body>
    </style>
</head>
<?php
    require "dbConnect.php";
    $q = $_REQUEST["q"];
    if(empty($q))exit;
    $sql = "SELECT * FROM trucks WHERE employeeID ='".$q."'";
    
    $result = mysqli_query($conn, $sql);
    echo "<table class='table table-bordered no-margin'>
    <tr>
    <th>truckno</th>
    <th>make</th>
    <th>model</th>
    <th>year</th>
    <th>licenseplate</th>
    <th>EmployeeID</th>
    <th>Color</th>
    </tr>";

    while($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['truckNo'] . "</td>";
        echo "<td>" . $row['make'] . "</td>";
        echo "<td>" . $row['model'] . "</td>";
        echo "<td>" . $row['year'] . "</td>";
        echo "<td>" . $row['licenseplateNo'] . "</td>";
        echo "<td>" . $row['employeeID'] . "</td>";
        echo "<td>" . $row['color'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
   
    
?>
</body>
</html>