<html>
<body>
<head>
    <style>
        table
        {
            width: 100%;
            border-collapse: collapse;
        }

        table, td, th 
        {
            border: 1px solid black;
            padding: 5px;
        }

        th {text-align: left;}
    </style>
</head>
<body>
    </style>
</head>
<?php
    require "dbConnect.php";
    $q = $_REQUEST["q"];
    if(empty($q))exit;
    $sql = "SELECT * FROM comments WHERE commentID ='".$q."'";
    
    $result = mysqli_query($conn, $sql);
    echo "<table class='table table-bordered no-margin'>
    <tr>
    <th>CommentTime</th>
    <th>CommentDate</th>
    <th>Type</th>
    <th>Description</th>
    </tr>";

    while($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['commentTime'] . "</td>";
        echo "<td>" . $row['commentDate'] . "</td>";
        echo "<td>" . $row['type'] . "</td>";
        echo "<td>" . $row['description'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
   
    
?>
</body>
</html>