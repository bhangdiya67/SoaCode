<?php
    require "dbConnect.php";
    $sql = "SELECT DISTINCTROW isSpecial FROM orders";
    
    $result = mysqli_query($conn, $sql);
    

    if (mysqli_num_rows($result) > 0)
     {
        // output data of each row
        echo "<form>";
        echo "<div class='form-group'><select class=form-control name=Special Orders onchange=specialOrders(this.value)>";
        echo"<option value='0'>Select Special Orders Of Employee</option>";
        while($row = mysqli_fetch_assoc($result))
         {
           echo"<option>$row[isSpecial]</option>";
        }
        echo "</select></div>";
        echo "</form>";
    } 
    else 
    {
        echo "0 results";
    }

    
    
?>